public class Main {
    public static void main(String[] args) {
        Controlador control = new Controlador();
        control.Inciar();
    }

    //C:\Users\Usuario\Desktop\Universidad\Tercer Semestre\Datos Compu\HDT3-V2\src
}
